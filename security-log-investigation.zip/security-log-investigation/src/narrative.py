"""Analyst narrative built from computed results, shared by the workbook and the PDF."""
from investigation import analyse, fmt_td


def build(R):
    bf, sp = R["r1"][0], R["r2"][0]
    ua = next(r for r in R["r3"] if r["fired"])
    lat = {l["control"]: l for l in R["latency"]}
    lock, rl = lat["account_lock"], lat["rate_limit"]
    gaps_bf = "/".join(f"{g:.0f}" for g in bf["gaps_s"])
    gaps_sp = "/".join(f"{g:.0f}" for g in sp["gaps_s"])
    since = fmt_td(ua["since_last_failure_s"])
    N = {}

    N["findings"] = [
        {"id": "F1", "title": "Three failed logins then lockout on stu-117",
         "class": "Likely user mistake (targeted guessing not excluded)", "confidence": "Medium", "risk": "Low",
         "events": "E02-E05",
         "evidence": f"3 password failures for stu-117 from 198.51.100.27 (device windows) in {bf['duration_s']:.0f} s, "
                     f"gaps {gaps_bf} s; account_lock applied 45 s after the 3rd failure. No success afterwards in this log.",
         "inference": "Consistent device, one IP, one account and human-like pacing fit a forgotten or mistyped password. "
                      "A slow, targeted guess cannot be ruled out from three events.",
         "rationale": "One account, contained by the lock, no sign of success: low likelihood of malice and low impact.",
         "action": "Confirm the user recovered through a verified reset; watch stu-117 for further failures from other IPs.",
         "verify": "No new failures/successes for stu-117 from unfamiliar IPs after unlock."},
        {"id": "F2", "title": "Password spraying from 203.0.113.42",
         "class": "Suspicious: credential spraying pattern", "confidence": "High", "risk": "High",
         "events": "E06-E10",
         "evidence": f"4 failures against 4 different accounts (stu-209, stu-311, stu-415, stu-502), one attempt each, "
                     f"from one IP with device 'unknown', gaps {gaps_sp} s, {sp['duration_s']:.0f} s in total. "
                     f"A rate_limit block followed {rl['after_threshold_s']:.0f} s after the last attempt (E10, on stu-209). "
                     "No successful login from this IP appears in the log.",
         "inference": "One attempt per account at machine pace, with no client identity, is the signature of automated spraying "
                      "(trying one likely password across many accounts to stay under per-account lockouts). Intent: credential theft (assumed).",
         "rationale": "Deliberate multi-account attack (high likelihood) against student accounts (medium impact); contained so far, "
                      "but the scope of the block is unknown and a slower retry or a new IP would not be caught by it.",
         "action": "Check the three other targets for successes; confirm whether E10 blocks the IP or only stu-209; block or challenge the IP.",
         "verify": "Replay log: R2 fires once on 203.0.113.42; post-fix test shows a 5th account attempt from that IP is refused."},
        {"id": "F3", "title": "Possible account takeover: stu-311 login from a new IP and device",
         "class": "Unconfirmed: needs verification with the account owner", "confidence": "Low-Medium", "risk": "High (provisional)",
         "events": "E07, E12",
         "evidence": f"stu-311 was a spray target (failed from 203.0.113.42 at 09:21:13, E07). {since} later (11:47:09, E12) it logged in "
                     "successfully from 192.0.2.99 on an ios device, an IP and device not previously seen for that account. "
                     "192.0.2.99 shares a /24 with stu-104's normal IP 192.0.2.18.",
         "inference": "Could be the owner on a new phone (the shared /24 hints at a common network) or an attacker who guessed the password, "
                      "possibly from another IP. The link to the spray is circumstantial: different IP, 2+ hours apart, no history for stu-311.",
         "rationale": "A success is the only event that gives an attacker access, so impact is high; likelihood is unproven. "
                      "Rated High until verified because verification is cheap.",
         "action": "Verify with the owner via a trusted channel; if not confirmed reset the password, revoke sessions and refresh tokens, review activity after E12.",
         "verify": "Owner confirmation recorded; if reset, old session/refresh token rejected."},
    ]

    N["compare"] = [
        ("Accounts targeted", "1 (stu-117)", "4 (stu-209, 311, 415, 502)"),
        ("Attempts per account", "3", "1 each"),
        ("Source IPs", "1 (198.51.100.27)", "1 (203.0.113.42)"),
        ("Device", "windows (consistent, identified)", "unknown on 4 of 4"),
        ("Pacing", f"{gaps_bf} s gaps: human retyping is plausible", f"{gaps_sp} s gaps: faster than manual entry"),
        ("Duration", f"{bf['duration_s']:.0f} s for 3 attempts", f"{sp['duration_s']:.0f} s for 4 attempts"),
        ("Outcome", "Lock applied; no success seen", "Rate-limit block; no success from this IP"),
        ("Reading", "Likely user mistake (medium confidence)", "Suspicious: spraying (high confidence)"),
    ]

    N["timeline"] = [  # (time label, ts iso, event ids, evidence, interpretation, confidence, thread)
        ("09:00:12", "2026-08-01T09:00:12Z", "E01", "stu-104 password login succeeds from 192.0.2.18 (android).",
         "Normal start of session; this IP+device becomes the known-good reference for stu-104.", "High", "Baseline"),
        ("09:03:44", "2026-08-01T09:03:44Z", "E02-E04", f"3 failed logins for stu-117 from 198.51.100.27 (windows), gaps {gaps_bf} s.",
         "Probably a forgotten or mistyped password; targeted guessing not excluded.", "Medium", "F1"),
        ("09:05:03", "2026-08-01T09:05:03Z", "E05", f"account_lock applied to stu-117, {lock['after_threshold_s']:.0f} s after the 3rd failure.",
         "Lockout control works; the 45 s lag is a delay worth tightening.", "High", "F1"),
        ("09:21:10", "2026-08-01T09:21:10Z", "E06-E09", f"4 failures, 4 accounts, one IP (203.0.113.42), device unknown, gaps {gaps_sp} s.",
         "Password-spraying pattern: automated, one attempt per account.", "High", "F2"),
        ("09:22:01", "2026-08-01T09:22:01Z", "E10", f"rate_limit 'blocked' for stu-209 from 203.0.113.42, {rl['after_threshold_s']:.0f} s after the last attempt.",
         "Control engaged; whether it blocks the IP or just the account is not shown.", "Medium", "F2"),
        ("10:15:32", "2026-08-01T10:15:32Z", "E11", "stu-104 refresh_token succeeds from 192.0.2.18 (android), 1 h 15 min after login.",
         "Normal session continuation: same IP and device as E01.", "High", "Baseline"),
        ("11:47:09", "2026-08-01T11:47:09Z", "E12", f"stu-311 password login succeeds from 192.0.2.99 (ios), {since} after the spray failure.",
         "Possible takeover or a legitimate new device: unconfirmed.", "Low-Medium", "F3"),
    ]

    N["register"] = [  # (id, statement, type, confidence, confirm/refute)
        ("E-1", "stu-117: 3 consecutive failures, one IP and device, 34 s, then account_lock (E02-E05).", "Evidence", "High", "Log rows."),
        ("A-1", "The stu-117 failures were the user's own mistakes.", "Assumption", "Medium",
         "Confirm: user reset request after lock. Refute: failures for stu-117 from other IPs, or other accounts tried from 198.51.100.27."),
        ("E-2", "4 different accounts failed once each from 203.0.113.42 within 12 s, device unknown (E06-E09).", "Evidence", "High", "Log rows."),
        ("A-2", "That burst was automated password spraying.", "Assumption", "High",
         "Refute: the IP is a shared NAT/campus gateway with 4 users genuinely mistyping within 12 s (unlikely)."),
        ("A-3", "The spray aimed to steal credentials.", "Assumption", "Medium", "Needs threat intel or a successful login to confirm."),
        ("E-3", "rate_limit 'blocked' logged for stu-209 from 203.0.113.42 at 09:22:01 (E10).", "Evidence", "High", "Log row."),
        ("U-1", "Unknown: whether E10 blocks the IP or only the account.", "Unknown", "n/a", "Check rate-limiter configuration/logs."),
        ("E-4", "No successful login from 203.0.113.42 appears in this 2 h 47 min log.", "Evidence", "High", "Limited to this log window and source."),
        ("A-4", "None of the 4 spray targets was compromised by that IP.", "Assumption", "Medium", "Check wider logs and password-change events."),
        ("E-5", "stu-311 succeeded from 192.0.2.99/ios at 11:47:09 after a failure from 203.0.113.42 at 09:21:13 (E07, E12).", "Evidence", "High", "Log rows."),
        ("A-5", "The 11:47 login was made by an attacker.", "Assumption", "Low-Medium",
         "Confirm: owner denies it. Refute: owner confirms new phone/network. 192.0.2.99 shares a /24 with stu-104's IP."),
        ("A-6", "The failed stu-311 attempt at 09:21:13 was the attacker, not the owner.", "Assumption", "Medium", "Owner interview."),
        ("L-1", "Limitation: the log has no logout, MFA, page-access or password-change events, so post-login impact is unknowable here.", "Limitation", "n/a", "Collect richer logs."),
        ("L-2", "Limitation: 12 events over 2 h 47 min cannot support a statistical baseline; thresholds are rule-of-thumb values to be tuned on 30 days of data.", "Limitation", "n/a", "Re-run on a larger log."),
    ]

    N["threat_model"] = [  # template from the lab brief
        {"id": "F1", "asset": "Student account stu-117; owner: portal operations team",
         "boundary": "Internet -> login endpoint (password_login)",
         "scenario": "Guessing or mistyping the password; precondition: knows the username",
         "control": "Account lock after 3 failures (E05)", "risk": "Low: one account, contained",
         "mitigation": "Progressive delay; self-service reset; alert only on escalation", "verify": "Unit test: 3 failures -> lock inside 1 s"},
        {"id": "F2", "asset": "Student accounts stu-209/311/415/502; owner: portal operations team",
         "boundary": "Internet -> login endpoint (password_login)",
         "scenario": "Spraying one likely password across many accounts; precondition: list of usernames",
         "control": "rate_limit block (E10), scope unclear", "risk": "High: deliberate and automated, partly contained",
         "mitigation": "IP-level counter, distinct-account rule R2, challenge/block IP, MFA", "verify": "Replay CSV: R2 fires once; simulated 5th account from same IP is refused"},
        {"id": "F3", "asset": "Account stu-311 and its sessions/refresh tokens; owner: portal operations team",
         "boundary": "Internet -> login endpoint, then session/refresh_token endpoint",
         "scenario": "Successful guess or reused password from a new IP/device; precondition: weak or reused password",
         "control": "None observed (login allowed)", "risk": "High (provisional): only success event for a targeted account",
         "mitigation": "Step-up MFA on new IP+device after recent failures (R3), notify user, revoke sessions on doubt",
         "verify": "Replay CSV: R3 fires on E12 only; test login from new pair triggers step-up"},
    ]

    N["rules"] = [  # id, name, logic, key, window, threshold, severity, response, fires
        ("R1", "Brute force (one account)", "Failed password logins for one account from any IP", "user_id", "300 s", ">= 3 failures",
         "Medium; Low if single IP+device with human pacing; High at >= 10 failures or success after cluster",
         "Progressive delay / soft-lock; notify user", "Fires: stu-117 (E02-E04)"),
        ("R2", "Password spraying (one IP)", "Failures across several accounts from one IP, few attempts each", "source_ip", "120 s",
         ">= 3 distinct accounts, <= 2 attempts per account", "High", "Challenge or block IP; review targets for successes", "Fires: 203.0.113.42 (E06-E09)"),
        ("R3", "Unusual access after exposure", "Successful password login from an IP+device pair not seen for the account, with >= 1 failure for that account in the previous 24 h (any IP)",
         "user_id", "24 h look-back", "new pair AND >= 1 prior failure", "High (provisional)", "Step-up MFA; notify owner; revoke sessions if not confirmed", "Fires: E12 (stu-311)"),
        ("R4", "Control health", "A lock or rate-limit event arrives later than the SLO after the threshold was crossed", "control event", "10 s SLO (proposed)",
         "latency > 10 s", "Medium", "Fix enforcement path; alert to platform team", f"Fires: lock {lock['after_threshold_s']:.0f} s, rate limit {rl['after_threshold_s']:.0f} s"),
    ]

    N["recs"] = [  # id, priority, type, action, finding, verification
        ("A1", "P1", "Response", "Verify the stu-311 login at 11:47:09 with the owner through a trusted channel. If not confirmed: reset password, revoke sessions and refresh tokens, review activity after E12.", "F3", "Owner response recorded; old tokens rejected."),
        ("A2", "P1", "Response", "Review wider logs for stu-209, stu-415 and stu-502 for successful logins or password changes since 09:21 and notify the owners.", "F2", "No unexplained successes in the wider logs."),
        ("A3", "P1", "Response", "Confirm whether the 09:22:01 block (E10) covers the whole IP or only stu-209; block or challenge 203.0.113.42 if it does not.", "F2", "A further attempt from the IP is refused."),
        ("A4", "P2", "Response", "Confirm stu-117 recovered through a verified reset and that locks have a defined expiry and unlock path.", "F1", "Unlock path documented; no new failures."),
        ("C1", "P1", "Rate limit", "Add an IP-level counter independent of account: challenge or block an IP at >= 3 distinct accounts failing within 2 min, or >= 10 failures in 5 min.", "F2", "Replay and simulation: 5th account from the IP is refused."),
        ("C2", "P2", "Rate limit", "Per account: progressive delay (3 failures -> 30 s, 5 -> 15 min soft-lock or step-up) instead of a hard lock when failures come from many IPs, to avoid lockout abuse.", "F1, F2", "Unit tests for each tier."),
        ("C3", "P2", "Rate limit", f"Enforce limits inline at the threshold crossing. Observed lag was {lock['after_threshold_s']:.0f} s (lock) and {rl['after_threshold_s']:.0f} s (rate limit), a window for extra attempts.", "F1, F2", "Lock/block logged within 1 s of the threshold event."),
        ("C4", "P1", "Rate limit", "Require step-up (MFA or email confirmation) for logins from a new IP+device when the account had a failure in the last 24 h.", "F3", "Test login from a new pair prompts step-up."),
        ("C5", "P3", "Rate limit", "Treat device='unknown' (no client identity) as a risk signal: stricter throttling.", "F2", "Unknown-device clients throttled in test."),
        ("D1", "P1", "Detection", "Deploy rules R1-R4 as alerts with the severities above; keep this CSV as a regression test (expected: R1 stu-117, R2 203.0.113.42, R3 E12, nothing for stu-104).", "F1-F3", "Script reproduces expected alerts and no others."),
        ("D2", "P2", "Logging", "Enrich logs: user agent, ASN/geo, session ID, MFA outcome, and for lock/block events the reason, scope and threshold. Log every blocked attempt.", "F2, F3", "New fields present in sample events."),
        ("D3", "P2", "Detection", "Build a 30-day per-account baseline (known IP/device pairs, usual hours) and allow-list shared campus/NAT ranges for R2.", "F3", "Baseline job output; false-positive review."),
        ("D4", "P3", "Detection", "Review alert precision monthly and tune thresholds; expect R1 to produce user-mistake false positives.", "All", "Monthly precision metric tracked."),
    ]
    return N


if __name__ == "__main__":
    import sys
    from pathlib import Path
    R = analyse(Path(__file__).resolve().parent.parent / "authentication-log-sample.csv")
    N = build(R)
    for f in N["findings"]:
        print(f["id"], f["risk"], "|", f["evidence"])
