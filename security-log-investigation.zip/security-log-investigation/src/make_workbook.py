from datetime import datetime
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from investigation import analyse
from narrative import build

ROOT = Path(__file__).resolve().parent.parent
R = analyse(ROOT / "authentication-log-sample.csv")
N = build(R)
EV = R["data"]["events"]
LAST = len(EV) + 1  # last data row on Normalized_Log

F = "Arial"
HDR_FILL = PatternFill("solid", fgColor="1F3864")
FILLS = {"fail": PatternFill("solid", fgColor="F8D7DA"), "ok": PatternFill("solid", fgColor="D4EDDA"),
         "ctl": PatternFill("solid", fgColor="D6E4F0"), "hi": PatternFill("solid", fgColor="FFF3CD"),
         "sec": PatternFill("solid", fgColor="E7ECF4")}
thin = Side(style="thin", color="BBBBBB")
BOX = Border(left=thin, right=thin, top=thin, bottom=thin)
WRAP = Alignment(wrap_text=True, vertical="top")
DT = "yyyy-mm-dd hh:mm:ss"

wb = Workbook()


def rng(col):  # absolute range on Normalized_Log
    return f"Normalized_Log!${col}$2:${col}${LAST}"


def title(ws, text, sub=None):
    ws["A1"] = text; ws["A1"].font = Font(name=F, size=14, bold=True, color="1F3864")
    if sub:
        ws["A2"] = sub; ws["A2"].font = Font(name=F, size=9, italic=True, color="555555")


def header(ws, row, labels, col=1):
    for i, l in enumerate(labels):
        c = ws.cell(row=row, column=col + i, value=l)
        c.font = Font(name=F, bold=True, color="FFFFFF", size=10); c.fill = HDR_FILL
        c.alignment = Alignment(wrap_text=True, vertical="center"); c.border = BOX


def put(ws, row, values, col=1, fmt=None, fill=None, bold=False):
    for i, v in enumerate(values):
        c = ws.cell(row=row, column=col + i, value=v)
        c.font = Font(name=F, size=10, bold=bold); c.alignment = WRAP; c.border = BOX
        if fill: c.fill = fill
        if fmt and i in fmt: c.number_format = fmt[i]


def section(ws, row, text):
    c = ws.cell(row=row, column=1, value=text)
    c.font = Font(name=F, bold=True, size=11, color="1F3864")


def widths(ws, ws_widths):
    for i, w in enumerate(ws_widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w


# ------------------------------------------------------------------ Raw_Log
raw = wb.active; raw.title = "Raw_Log"
title(raw, "Raw log (as supplied, unmodified)", "Source: authentication-log-sample.csv. Kept for traceability; analysis uses Normalized_Log.")
header(raw, 4, ["file_line", "timestamp", "user_id", "source_ip", "event", "result", "device"])
for i, r in enumerate(R["data"]["raw_rows"]):
    put(raw, 5 + i, [i + 2, r["timestamp"], r["user_id"], r["source_ip"], r["event"], r["result"], r["device"]])
widths(raw, [10, 24, 10, 16, 16, 10, 10])

# ------------------------------------------------------------ Normalized_Log
nl = wb.create_sheet("Normalized_Log")
cols = ["event_id", "ts_utc", "user_id", "source_ip", "ip_range", "subnet24", "event", "event_class", "result_raw",
        "outcome", "device", "device_known", "auth_failure", "auth_success", "control_event", "first_fail_ip_user"]
header(nl, 1, cols)
for i, e in enumerate(EV):
    r = i + 2
    vals = [e["event_id"], e["ts"].replace(tzinfo=None), e["user_id"], e["source_ip"], e["ip_range"], e["subnet24"],
            e["event"], e["event_class"], e["result_raw"], e["outcome"], e["device"], int(e["device_known"]),
            e["auth_failure"], e["auth_success"], e["control_event"],
            f'=IF(AND(M{r}=1,COUNTIFS($D$2:D{r},D{r},$C$2:C{r},C{r},$M$2:M{r},1)=1),1,0)']
    fill = FILLS["fail"] if e["auth_failure"] else FILLS["ctl"] if e["control_event"] else FILLS["ok"]
    put(nl, r, vals, fmt={1: DT}, fill=fill)
nl.freeze_panes = "A2"
widths(nl, [9, 20, 9, 15, 12, 16, 15, 14, 10, 16, 9, 10, 10, 10, 10, 12])
nl.cell(row=LAST + 2, column=1, value="Notes: ts_utc is canonical UTC. auth_failure/auth_success count password_login only, so account_lock 'success' "
        "(a lock being applied) is never counted as a login. first_fail_ip_user = 1 on the first failure for each IP+account pair (helper for distinct-account counts). "
        "Row colours: red = failed login, green = success, blue = control event.").font = Font(name=F, size=9, italic=True)

# ------------------------------------------------------------- Data_Quality
dq = wb.create_sheet("Data_Quality")
title(dq, "Data quality and normalisation", "Checks run by src/investigation.py before any analysis. No rows were removed.")
header(dq, 4, ["Check", "Result", "Detail"])
for i, (name, ok, detail) in enumerate(R["dq"]):
    put(dq, 5 + i, [name, "PASS" if ok else "NOTE", detail], fill=None if ok else FILLS["hi"])
r0 = 5 + len(R["dq"]) + 1
section(dq, r0, "Normalisation applied")
header(dq, r0 + 1, ["Field", "Rule", "Example"])
for i, row in enumerate([
    ("timestamp", "Parsed ISO-8601, converted to UTC (stored as a real datetime, not text)", "2026-08-01T09:03:44Z -> 2026-08-01 09:03:44"),
    ("source_ip", "Validated with Python ipaddress; labelled with RFC 5737 range and /24 subnet", "198.51.100.27 -> TEST-NET-2, 198.51.100.0/24"),
    ("user_id", "Trimmed, lower-cased, checked against stu-NNN", "stu-117"),
    ("event", "Lower-cased and mapped to a class: authentication / session / control", "password_login -> authentication"),
    ("result", "Kept raw, plus an event-aware 'outcome' so meanings are not mixed", "account_lock + success -> account_locked"),
    ("device", "Lower-cased; 'unknown' flagged via device_known = 0, 'server' = system-generated", "unknown -> device_known 0"),
    ("event_id", "Sequential E01..E12 in time order so findings can cite evidence", "E07")]):
    put(dq, r0 + 2 + i, row)
widths(dq, [42, 14, 90])

# ----------------------------------------------------------------- Baseline
bl = wb.create_sheet("Baseline")
title(bl, "Baseline (live formulas over Normalized_Log)",
      "12 events cannot support a statistical baseline; this sheet records the behavioural reference and counts the rules are tuned against.")
section(bl, 4, "Key metrics")
header(bl, 5, ["Metric", "Value", "Note"])
m = [("Total events", f"=COUNTA({rng('A')})", None, ""),
     ("First event (UTC)", f"=MIN({rng('B')})", DT, ""),
     ("Last event (UTC)", f"=MAX({rng('B')})", DT, ""),
     ("Time span", "=B8-B7", "[h]:mm:ss", ""),
     ("Password login attempts", f'=COUNTIFS({rng("G")},"password_login")', None, ""),
     ("Failed password logins", f"=SUM({rng('M')})", None, ""),
     ("Successful password logins", f"=SUM({rng('N')})", None, "account_lock 'success' excluded"),
     ("Failure rate", "=B11/B10", "0.0%", "Inflated by the tiny sample; do not use as a norm"),
     ("Distinct accounts", f"=SUMPRODUCT(1/COUNTIF({rng('C')},{rng('C')}))", None, ""),
     ("Distinct source IPs", f"=SUMPRODUCT(1/COUNTIF({rng('D')},{rng('D')}))", None, ""),
     ("Control events (lock / rate limit)", f"=SUM({rng('O')})", None, "")]
for i, (lab, f, fmt, note) in enumerate(m):
    put(bl, 6 + i, [lab, f, note], fmt={1: fmt} if fmt else None)
r = 6 + len(m) + 1
section(bl, r, "Events by type and result"); header(bl, r + 1, ["Event", "Result", "Count"])
combos = [("password_login", "success"), ("password_login", "failure"), ("refresh_token", "success"),
          ("account_lock", "success"), ("rate_limit", "blocked")]
for i, (e, res) in enumerate(combos):
    put(bl, r + 2 + i, [e, res, f'=COUNTIFS({rng("G")},A{r+2+i},{rng("I")},B{r+2+i})'])
r2 = r + 2 + len(combos)
put(bl, r2, ["Total", "", f"=SUM(C{r+2}:C{r2-1})"], bold=True)
r = r2 + 2
section(bl, r, "By source IP"); header(bl, r + 1, ["Source IP", "Range", "Events", "Failures", "Successes", "Distinct accounts failed", "Failure rate", "Devices seen"])
for i, (ip, d) in enumerate(R["baseline"]["per_ip"].items()):
    rr = r + 2 + i
    rngl = next(e["ip_range"] for e in EV if e["source_ip"] == ip)
    put(bl, rr, [ip, rngl, f'=COUNTIFS({rng("D")},A{rr})', f'=SUMIFS({rng("M")},{rng("D")},A{rr})',
                 f'=SUMIFS({rng("N")},{rng("D")},A{rr})', f'=SUMIFS({rng("P")},{rng("D")},A{rr})',
                 f'=IF(D{rr}+E{rr}=0,"n/a",D{rr}/(D{rr}+E{rr}))', ", ".join(d["devices"])], fmt={6: "0%"})
IP_ROWS = (r + 2, r + 1 + len(R["baseline"]["per_ip"]))
r = IP_ROWS[1] + 2
section(bl, r, "By account"); header(bl, r + 1, ["Account", "Events", "Failures", "Successes", "First seen", "Last seen", "IPs seen"])
for i, (u, d) in enumerate(R["baseline"]["per_user"].items()):
    rr = r + 2 + i
    put(bl, rr, [u, f'=COUNTIFS({rng("C")},A{rr})', f'=SUMIFS({rng("M")},{rng("C")},A{rr})',
                 f'=SUMIFS({rng("N")},{rng("C")},A{rr})', f'=_xlfn.MINIFS({rng("B")},{rng("C")},A{rr})',
                 f'=_xlfn.MAXIFS({rng("B")},{rng("C")},A{rr})', ", ".join(d["ips"])], fmt={4: DT, 5: DT})
r = r + 2 + len(R["baseline"]["per_user"]) + 1
section(bl, r, "Behavioural reference (what 'normal' looks like here)")
put(bl, r + 1, [R["baseline"]["reference_pattern"] + ". Only stu-104 shows this clean pattern; 5 of 6 accounts appear in a failure cluster or an unusual-access event."])
bl.merge_cells(start_row=r + 1, start_column=1, end_row=r + 1, end_column=8); bl.row_dimensions[r + 1].height = 32
widths(bl, [34, 22, 14, 12, 20, 20, 14, 18])

# ----------------------------------------------------------- Detection_Rules
dr = wb.create_sheet("Detection_Rules")
title(dr, "Detection rules and live tests", "Thresholds are rule-of-thumb values for this lab and should be tuned on 30 days of data.")
header(dr, 4, ["ID", "Name", "Logic", "Key", "Window", "Threshold", "Severity", "Response", "Result on this log"])
for i, row in enumerate(N["rules"]):
    put(dr, 5 + i, list(row))
    dr.row_dimensions[5 + i].height = 78
r = 5 + len(N["rules"]) + 1
section(dr, r, "Live test R1: failures per account within 300 s (rule fires if count >= 3 and span <= 300 s)")
header(dr, r + 1, ["Account", "Failures", "First failure", "Last failure", "Span (s)", "R1 fires?"])
users = list(R["baseline"]["per_user"])
for i, u in enumerate(users):
    rr = r + 2 + i
    cnt = f'COUNTIFS({rng("C")},A{rr},{rng("M")},1)'
    put(dr, rr, [u, f"={cnt}",
                 f'=IF(B{rr}=0,"",_xlfn.MINIFS({rng("B")},{rng("C")},A{rr},{rng("M")},1))',
                 f'=IF(B{rr}=0,"",_xlfn.MAXIFS({rng("B")},{rng("C")},A{rr},{rng("M")},1))',
                 f'=IF(B{rr}=0,"",ROUND((D{rr}-C{rr})*86400,0))',
                 f'=IF(AND(B{rr}>=3,B{rr}<>0,E{rr}<>"",E{rr}<=300),"FIRES","no")'], fmt={2: DT, 3: DT})
r = r + 2 + len(users) + 1
section(dr, r, "Live test R2: distinct accounts failing per IP within 120 s (fires if >= 3 accounts, <= 2 attempts per account)")
header(dr, r + 1, ["Source IP", "Failures", "Distinct accounts", "Attempts per account", "Span (s)", "R2 fires?"])
ips = list(R["baseline"]["per_ip"])
for i, ip in enumerate(ips):
    rr = r + 2 + i
    put(dr, rr, [ip, f'=SUMIFS({rng("M")},{rng("D")},A{rr})', f'=SUMIFS({rng("P")},{rng("D")},A{rr})',
                 f'=IF(C{rr}=0,"",B{rr}/C{rr})',
                 f'=IF(B{rr}=0,"",ROUND((_xlfn.MAXIFS({rng("B")},{rng("D")},A{rr},{rng("M")},1)-_xlfn.MINIFS({rng("B")},{rng("D")},A{rr},{rng("M")},1))*86400,0))',
                 f'=IF(AND(C{rr}>=3,D{rr}<>"",D{rr}<=2,E{rr}<>"",E{rr}<=120),"FIRES","no")'], fmt={3: "0.0"})
r = r + 2 + len(ips) + 1
section(dr, r, "Live test R3: each successful password login vs the account's own history")
header(dr, r + 1, ["Event", "Account", "Source IP", "Device", "Time (UTC)", "Earlier events for account", "Failures in previous 24 h (any IP)", "IP+device seen before?", "R3 fires?"])
succ = [e for e in EV if e["auth_success"]]
for i, e in enumerate(succ):
    rr = r + 2 + i
    put(dr, rr, [e["event_id"], e["user_id"], e["source_ip"], e["device"],
                 f'=INDEX({rng("B")},MATCH(A{rr},{rng("A")},0))',
                 f'=COUNTIFS({rng("C")},B{rr},{rng("B")},"<"&E{rr})',
                 f'=COUNTIFS({rng("C")},B{rr},{rng("M")},1,{rng("B")},"<"&E{rr},{rng("B")},">="&(E{rr}-1))',
                 f'=IF(COUNTIFS({rng("C")},B{rr},{rng("D")},C{rr},{rng("K")},D{rr},{rng("B")},"<"&E{rr},{rng("J")},"login_success")'
                 f'+COUNTIFS({rng("C")},B{rr},{rng("D")},C{rr},{rng("K")},D{rr},{rng("B")},"<"&E{rr},{rng("J")},"token_refreshed")>0,"yes","NEW")',
                 f'=IF(AND(H{rr}="NEW",G{rr}>=1),"FIRES","no")'], fmt={4: DT})
r = r + 2 + len(succ) + 1
section(dr, r, "Live test R4: control latency (seconds from the event that crossed the threshold to the control action)")
header(dr, r + 1, ["Control", "Control event", "Threshold event", "Latency (s)", "SLO (s)", "R4 fires?"])
for i, (lab, ce, te) in enumerate([("account_lock", "E05", "E04"), ("rate_limit", "E10", "E09")]):
    rr = r + 2 + i
    put(dr, rr, [lab, ce, te, f'=ROUND((INDEX({rng("B")},MATCH(B{rr},{rng("A")},0))-INDEX({rng("B")},MATCH(C{rr},{rng("A")},0)))*86400,0)',
                 10, f'=IF(D{rr}>E{rr},"FIRES","no")'])
r = r + 5
put(dr, r, ["Benign check: stu-104's login (E01) and token refresh (E11) match no rule, so the rules do not alert on the normal reference pattern."])
dr.merge_cells(start_row=r, start_column=1, end_row=r, end_column=9)
widths(dr, [16, 24, 40, 18, 16, 22, 24, 28, 26])

# ------------------------------------------------------------------ Findings
fd = wb.create_sheet("Findings")
title(fd, "Findings: evidence kept separate from inference")
header(fd, 3, ["ID", "Finding", "Classification", "Events", "Evidence (what the log shows)", "Inference (what we think it means)", "Confidence", "Risk", "Risk rationale", "Recommended action", "Verification"])
for i, f in enumerate(N["findings"]):
    put(fd, 4 + i, [f["id"], f["title"], f["class"], f["events"], f["evidence"], f["inference"], f["confidence"], f["risk"],
                    f["rationale"], f["action"], f["verify"]])
    fd.row_dimensions[4 + i].height = 150
r = 4 + len(N["findings"]) + 1
section(fd, r, "User mistake vs suspicious pattern")
header(fd, r + 1, ["Signal", "F1: stu-117 cluster", "F2: 203.0.113.42 cluster"])
for i, row in enumerate(N["compare"]):
    put(fd, r + 2 + i, list(row), bold=(i == len(N["compare"]) - 1))
widths(fd, [24, 30, 30, 10, 48, 48, 12, 14, 36, 40, 34])

# ------------------------------------------------------------------ Timeline
tl = wb.create_sheet("Timeline")
title(tl, "Reconstructed timeline (all times UTC, 2026-08-01)", "Evidence column = what the log shows. Interpretation column = analyst inference.")
header(tl, 4, ["#", "Time (UTC)", "Gap since previous row", "Events", "Evidence", "Interpretation (assumption)", "Confidence", "Thread"])
for i, (lab, iso, ids, evd, interp, conf, th) in enumerate(N["timeline"]):
    rr = 5 + i
    put(tl, rr, [i + 1, datetime.strptime(iso, "%Y-%m-%dT%H:%M:%SZ"), "" if i == 0 else f"=B{rr}-B{rr-1}",
                 ids, evd, interp, conf, th], fmt={1: DT, 2: "[h]:mm:ss"},
        fill={"F1": FILLS["fail"], "F2": FILLS["fail"], "F3": FILLS["hi"]}.get(th, FILLS["ok"]))
    tl.row_dimensions[rr].height = 48
widths(tl, [5, 20, 16, 10, 55, 55, 12, 10])

# ------------------------------------------------------------ Evidence_Register
er = wb.create_sheet("Evidence_vs_Assumptions")
title(er, "Evidence vs assumptions register", "E = evidence in the log, A = assumption, U = unknown, L = limitation.")
header(er, 3, ["ID", "Statement", "Type", "Confidence", "What would confirm or refute it"])
for i, row in enumerate(N["register"]):
    put(er, 4 + i, list(row), fill=FILLS["hi"] if row[2] in ("Assumption", "Unknown") else None)
widths(er, [7, 70, 13, 13, 70])

# --------------------------------------------------------------- Threat_Model
tm = wb.create_sheet("Threat_Model")
title(tm, "Threat model (template from the lab brief)", "Asset/owner, trust boundary, scenario, existing control, risk, mitigation and verification.")
header(tm, 3, ["ID", "Asset and owner", "Trust boundary / entry point", "Threat scenario and precondition", "Existing control and evidence", "Risk rating and rationale", "Recommended mitigation", "Verification step"])
for i, t in enumerate(N["threat_model"]):
    put(tm, 4 + i, [t["id"], t["asset"], t["boundary"], t["scenario"], t["control"], t["risk"], t["mitigation"], t["verify"]])
    tm.row_dimensions[4 + i].height = 70
widths(tm, [6, 30, 28, 34, 28, 28, 36, 34])

# ----------------------------------------------------------- Recommendations
rc = wb.create_sheet("Recommendations")
title(rc, "Response actions, rate-limit controls and detections", "P1 = do now, P2 = this sprint, P3 = backlog.")
header(rc, 3, ["ID", "Priority", "Type", "Action", "Addresses", "How to verify"])
for i, row in enumerate(N["recs"]):
    put(rc, 4 + i, list(row)); rc.row_dimensions[4 + i].height = 52
widths(rc, [6, 9, 12, 80, 10, 40])

# ------------------------------------------------------------------- Summary
sm = wb.create_sheet("Summary", 0)
title(sm, "Security Log Investigation: student portal authentication log",
      "Synthetic training data (RFC 5737 documentation IPs). Defensive analysis only. All times UTC.")
section(sm, 4, "Scope")
put(sm, 5, ["Source: authentication-log-sample.csv (12 events, one day). Questions: what is the baseline, which failures are mistakes vs suspicious, what happened when, and what controls would catch it."])
sm.merge_cells("A5:F5"); sm.row_dimensions[5].height = 34
section(sm, 7, "Key numbers (live)")
header(sm, 8, ["Metric", "Value"])
for i, (lab, ref, fmt) in enumerate([("Events analysed", "=Baseline!B6", None), ("Time span", "=Baseline!B9", "[h]:mm:ss"),
                                    ("Failed password logins", "=Baseline!B11", None), ("Successful password logins", "=Baseline!B12", None),
                                    ("Accounts involved", "=Baseline!B14", None), ("Source IPs", "=Baseline!B15", None)]):
    put(sm, 9 + i, [lab, ref], fmt={1: fmt} if fmt else None)
section(sm, 16, "Findings at a glance")
header(sm, 17, ["ID", "Finding", "Classification", "Confidence", "Risk", "Next step"])
for i, f in enumerate(N["findings"]):
    put(sm, 18 + i, [f["id"], f["title"], f["class"], f["confidence"], f["risk"], f["action"]],
        fill=FILLS["ok"] if f["risk"] == "Low" else FILLS["fail"] if f["risk"] == "High" else FILLS["hi"])
    sm.row_dimensions[18 + i].height = 62
section(sm, 22, "Bottom line")
put(sm, 23, ["One credential-spraying attempt (F2) was detected and rate-limited, no success from that IP is visible, but one of its targets (stu-311) logged in later from a new IP and device (F3). "
             "Verify that login first. The stu-117 lockout (F1) looks like an ordinary user mistake."])
sm.merge_cells("A23:F23"); sm.row_dimensions[23].height = 48
section(sm, 25, "Sheet guide")
for i, (s, d) in enumerate([("Raw_Log / Normalized_Log", "Input as supplied, and the cleaned, typed version used for analysis"),
                            ("Data_Quality", "Checks and normalisation rules"), ("Baseline", "Counts by event, IP and account (formulas)"),
                            ("Detection_Rules", "Rules R1-R4 with live formula tests"), ("Findings", "F1-F3, evidence vs inference, mistake vs suspicious comparison"),
                            ("Timeline", "Reconstructed sequence"), ("Evidence_vs_Assumptions", "What is known, assumed, unknown"),
                            ("Threat_Model", "Lab template per finding"), ("Recommendations", "Actions, rate-limit controls, detections")]):
    put(sm, 26 + i, [s, d]); sm.merge_cells(start_row=26 + i, start_column=2, end_row=26 + i, end_column=6)
widths(sm, [30, 36, 34, 14, 18, 60])

for ws in wb.worksheets:
    ws.sheet_view.showGridLines = False
    if ws.title in ("Findings", "Timeline", "Detection_Rules", "Recommendations", "Threat_Model", "Evidence_vs_Assumptions"):
        ws.sheet_properties.pageSetUpPr = None
out = ROOT / "security-log-investigation.xlsx"
wb.save(out); print("saved", out)
