import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime, timezone
from pathlib import Path
from investigation import analyse

ROOT = Path(__file__).resolve().parent.parent


def make(path=ROOT / "timeline.png"):
    R = analyse(ROOT / "authentication-log-sample.csv")
    ev = R["data"]["events"]
    users = sorted({e["user_id"] for e in ev}, reverse=True)
    lane = {u: i for i, u in enumerate(users)}
    d = lambda h, m: datetime(2026, 8, 1, h, m, tzinfo=timezone.utc)
    fig, (a, b) = plt.subplots(1, 2, figsize=(10, 3.6), sharey=True,
                               gridspec_kw={"width_ratios": [2.4, 1], "wspace": 0.05})
    style = {"login_failure": ("x", "#C62828", "Failed login"), "login_success": ("o", "#2E7D32", "Successful login"),
             "token_refreshed": ("D", "#2E7D32", "Token refresh"), "account_locked": ("s", "#1565C0", "Lock / block (control)"),
             "request_blocked": ("s", "#1565C0", None)}
    seen = set()
    for ax in (a, b):
        for e in ev:
            m, c, lab = style[e["outcome"]]
            lbl = lab if lab and lab not in seen and ax is a else None
            ax.scatter(e["ts"], lane[e["user_id"]], marker=m, c=c, s=70 if m != "x" else 80, linewidths=2,
                       label=lbl, zorder=3)
            if lbl:
                seen.add(lab)
        ax.grid(axis="x", color="#DDDDDD", zorder=0)
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
        for s in ("top", "right"):
            ax.spines[s].set_visible(False)
    a.set_xlim(d(8, 58), d(9, 26)); b.set_xlim(d(10, 10), d(11, 52))
    a.xaxis.set_major_locator(mdates.MinuteLocator(byminute=range(0, 60, 5)))
    b.xaxis.set_major_locator(mdates.MinuteLocator(byminute=[0, 30]))
    a.set_yticks(range(len(users))); a.set_yticklabels(users); a.set_ylim(-0.7, len(users) - 0.3)
    a.annotate("F1: 3 failures,\nthen lock", (d(9, 4), lane["stu-117"]), (d(9, 9), lane["stu-117"] + 0.9), fontsize=8,
               arrowprops=dict(arrowstyle="-", color="#555"))
    a.annotate("F2: 4 accounts in 12 s\n(same IP, device unknown)", (d(9, 21), lane["stu-415"]), (d(9, 11), lane["stu-415"] - 1.2), fontsize=8,
               arrowprops=dict(arrowstyle="-", color="#555"))
    b.annotate("F3: new IP + device", (d(11, 47), lane["stu-311"]), (d(10, 25), lane["stu-311"] + 1.1), fontsize=8,
               arrowprops=dict(arrowstyle="-", color="#555"))
    a.set_title("09:00 cluster (zoomed)", fontsize=9, loc="left"); b.set_title("later in the day", fontsize=9, loc="left")
    a.set_xlabel("Time (UTC)", fontsize=8); b.set_xlabel("Time (UTC), different scale", fontsize=8)
    a.legend(loc="lower left", fontsize=7, frameon=False, ncol=2, bbox_to_anchor=(0, -0.38))
    fig.savefig(path, dpi=200, bbox_inches="tight"); plt.close(fig)


if __name__ == "__main__":
    make()
