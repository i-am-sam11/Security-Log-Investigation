from pathlib import Path
from xml.sax.saxutils import escape as esc

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle)

from investigation import analyse, fmt_td
from narrative import build
import make_chart

ROOT = Path(__file__).resolve().parent.parent
FD = "/usr/share/fonts/truetype/dejavu/"
pdfmetrics.registerFont(TTFont("DV", FD + "DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("DV-B", FD + "DejaVuSans-Bold.ttf"))
pdfmetrics.registerFont(TTFont("DV-I", FD + "DejaVuSans-Oblique.ttf"))
pdfmetrics.registerFontFamily("DV", normal="DV", bold="DV-B", italic="DV-I", boldItalic="DV-B")

R = analyse(ROOT / "authentication-log-sample.csv")
N = build(R)
B = R["baseline"]
NAVY = colors.HexColor("#1F3864")
GREY = colors.HexColor("#F2F4F8")
RISK = {"Low": "#2E7D32", "High": "#C62828", "High (provisional)": "#C62828"}

ST = {
    "body": ParagraphStyle("body", fontName="DV", fontSize=9, leading=13, alignment=TA_LEFT, spaceAfter=5),
    "h1": ParagraphStyle("h1", fontName="DV-B", fontSize=13, leading=17, textColor=NAVY, spaceBefore=10, spaceAfter=5),
    "h2": ParagraphStyle("h2", fontName="DV-B", fontSize=10.5, leading=14, textColor=NAVY, spaceBefore=8, spaceAfter=3),
    "title": ParagraphStyle("title", fontName="DV-B", fontSize=18, leading=23, textColor=NAVY, spaceAfter=3),
    "sub": ParagraphStyle("sub", fontName="DV", fontSize=9.5, leading=13, textColor=colors.HexColor("#555555"), spaceAfter=8),
    "cell": ParagraphStyle("cell", fontName="DV", fontSize=7.8, leading=10.2),
    "cellb": ParagraphStyle("cellb", fontName="DV-B", fontSize=7.8, leading=10.2),
    "hdr": ParagraphStyle("hdr", fontName="DV-B", fontSize=7.8, leading=10.2, textColor=colors.white),
    "note": ParagraphStyle("note", fontName="DV-I", fontSize=8, leading=11, textColor=colors.HexColor("#555555"), spaceAfter=4),
    "bul": ParagraphStyle("bul", fontName="DV", fontSize=9, leading=13, leftIndent=12, bulletIndent=2, spaceAfter=2),
}
P = lambda t, s="body": Paragraph(t, ST[s])
C = lambda t, s="cell": Paragraph(esc(str(t)), ST[s])


def table(rows, widths, header=True, zebra=True, bold_first_col=False):
    data = []
    for i, r in enumerate(rows):
        data.append([c if not isinstance(c, str) else
                     Paragraph(esc(c), ST["hdr"] if (header and i == 0) else ST["cellb"] if (bold_first_col and j == 0) else ST["cell"])
                     for j, c in enumerate(r)])
    t = Table(data, colWidths=[w * mm for w in widths], repeatRows=1 if header else 0)
    style = [("VALIGN", (0, 0), (-1, -1), "TOP"), ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#BBBBBB")),
             ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
             ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]
    if header:
        style.append(("BACKGROUND", (0, 0), (-1, 0), NAVY))
    if zebra:
        for i in range(1 if header else 0, len(rows)):
            if i % 2 == 0:
                style.append(("BACKGROUND", (0, i), (-1, i), GREY))
    t.setStyle(TableStyle(style))
    return t


def footer(canvas, doc):
    canvas.saveState(); canvas.setFont("DV", 7.5); canvas.setFillColor(colors.HexColor("#666666"))
    canvas.drawString(18 * mm, 10 * mm, "Security Log Investigation - synthetic training data, defensive analysis only")
    canvas.drawRightString(192 * mm, 10 * mm, f"Page {doc.page}")
    canvas.restoreState()


def bullets(items):
    return [Paragraph(esc(t), ST["bul"], bulletText="\u2022") for t in items]


make_chart.make()
S = []
S += [P("Incident Report: Suspicious Authentication Activity", "title"),
      P("Student portal authentication log - reconstructed from a synthetic training dataset", "sub")]
S.append(table([["Log period", f"{B['first']} to {B['last']} ({fmt_td(B['span_s'])})"],
                ["Source", "authentication-log-sample.csv (12 events, EdVyro task source library)"],
                ["Environment", "Fictional student portal; documentation IP ranges (RFC 5737). No external system was scanned or contacted."],
                ["Status", "Findings open: verification of F3 and review of F2 targets pending"]],
               [30, 144], header=False, zebra=False, bold_first_col=True))

S.append(P("1. Executive summary", "h1"))
S.append(P(
    "The log shows three separate threads. A <b>password-spraying attempt</b> (F2) hit four accounts from one IP within 12 seconds and was rate-limited; "
    "no successful login from that IP is visible. Two hours later one of those four accounts, <b>stu-311, logged in successfully from a new IP and device</b> (F3). "
    "This may be the owner on a new phone or an account takeover, and the log alone cannot decide. A third thread, <b>three failed logins and a lockout on stu-117</b> (F1), "
    "looks like an ordinary user mistake. <b>The first action is to verify the stu-311 login with its owner.</b>"))
rows = [["ID", "Finding", "Classification", "Confidence", "Risk"]]
for f in N["findings"]:
    rows.append([f["id"], f["title"], f["class"], f["confidence"], f["risk"]])
S.append(table(rows, [10, 58, 62, 22, 22]))
S.append(Spacer(1, 4))
S.append(P("Immediate actions (P1)", "h2"))
S += bullets([a[3] for a in N["recs"] if a[0] in ("A1", "A2", "A3")])

S.append(P("2. Scope, data and method", "h1"))
S.append(P("The task was to establish a baseline, find clusters of failures, separate likely user mistakes from suspicious patterns, build a timeline and recommend "
           "detection and rate-limit controls. All analysis is reproducible with <font name='DV-B'>src/investigation.py</font>; the workbook "
           "<font name='DV-B'>security-log-investigation.xlsx</font> holds the same results with live formulas."))
S.append(P("<b>Normalisation.</b> Timestamps were parsed as ISO-8601 and converted to UTC datetimes; IPs were validated and labelled with their documentation range and /24 subnet; "
           "account IDs were trimmed and checked against the stu-NNN pattern; events were mapped to classes (authentication, session, control); results were kept raw and also "
           "mapped to an event-aware outcome; each row received an ID (E01-E12) so findings can cite evidence."))
S.append(P("<b>Data quality.</b> 12 of 12 rows parsed; no missing values, duplicates or invalid IPs; all timestamps were already in order. Two notes matter for the analysis: "
           "(1) four rows have <i>device = unknown</i>, all from one IP, treated as a signal rather than missing data; (2) <i>success</i> on an account_lock event means the lock was applied, "
           "not that anyone logged in, so it is kept out of the login counts. No rows were removed."))

_bl = [P("3. Baseline", "h1"), table([["Metric", "Value"],
                ["Events / accounts / source IPs", f"{B['total_events']} / {B['distinct_users']} / {B['distinct_ips']}"],
                ["Password logins", f"{B['password_logins']} ({B['failures']} failed, {B['successes']} successful)"],
                ["Other events", "1 token refresh, 1 account lock, 1 rate-limit block"],
                ["Events by hour (UTC)", ", ".join(f"{h}: {n}" for h, n in B["events_by_hour"].items())]], [60, 114]), Spacer(1, 4),
       P(f"<b>Reference pattern.</b> {esc(B['reference_pattern'])}. This is the only clean sequence in the log, and the rules below do not alert on it. "
           "<b>Caveat:</b> 12 events cannot support a statistical baseline. The 78% failure rate is a product of the sample, not a norm. Thresholds are rule-of-thumb values "
           "and should be tuned on about 30 days of real data.")]
S.append(KeepTogether(_bl))

S.append(P("4. Detection rules", "h1"))
S.append(table([["ID", "Rule", "Logic and threshold", "Severity", "Result on this log"]] +
               [[r[0], r[1], f"{r[2]}. Key: {r[3]}. Window: {r[4]}. Threshold: {r[5]}.", r[6], r[8].replace("Fires: ", "Fires: ")] for r in N["rules"]],
               [10, 28, 74, 34, 28]))
S.append(P("Each rule was also checked against the whole log: R1 fires only for stu-117, R2 only for 203.0.113.42, R3 only for E12, and nothing fires on stu-104. "
           "R4 uses a 10 s response target that I proposed; it is an assumption, not a measured standard.", "note"))

S.append(PageBreak())
S.append(P("5. Findings", "h1"))
for f in N["findings"]:
    colr = RISK.get(f["risk"], "#B26A00")
    blk = [P(f"{f['id']}. {esc(f['title'])}", "h2"),
           table([["Classification", f["class"]], ["Evidence", f["evidence"]], ["Inference", f["inference"]],
                  ["Confidence / risk", f"{f['confidence']} confidence. Risk: {f['risk']}. {f['rationale']}"],
                  ["Action", f["action"]], ["Verification", f["verify"]]], [30, 144], header=False, zebra=False, bold_first_col=True)]
    S.append(KeepTogether(blk))
    if f["id"] == "F2":
        S.append(P("User mistake or suspicious? The two clusters compared", "h2"))
        S.append(table([["Signal", "F1: stu-117", "F2: 203.0.113.42"]] + [list(r) for r in N["compare"]], [34, 70, 70]))

S.append(P("6. Timeline (UTC, 2026-08-01)", "h1"))
S.append(Image(str(ROOT / "timeline.png"), width=174 * mm, height=174 * mm * 0.43))
S.append(Spacer(1, 4))
S.append(table([["Time", "Events", "Evidence (log)", "Interpretation", "Conf."]] +
               [[t[0], t[2], t[3], t[4], t[5].replace("Low-Medium", "Low-Med")] for t in N["timeline"]], [19, 17, 62, 58, 18]))

S.append(PageBreak())
S.append(P("7. Evidence versus assumptions", "h1"))
S.append(P("Statements are labelled so a reader can see what the log proves and what is judgement.", "note"))
S.append(table([["ID", "Statement", "Type", "Conf.", "What would confirm or refute it"]] + [[c.replace("Low-Medium", "Low-Med") for c in r] for r in N["register"]], [10, 64, 20, 18, 62]))

S.append(P("8. Recommendations", "h1"))
S.append(P("P1 = do now, P2 = this sprint, P3 = backlog.", "note"))
S.append(table([["ID", "Pri", "Type", "Action", "For", "Verification"]] + [list(r) for r in N["recs"]], [9, 9, 17, 78, 11, 50]))

S.append(P("9. Limitations and handling", "h1"))
S += bullets([
    "The log has no logout, MFA, page-access or password-change events, so what happened after the 11:47 login cannot be determined from it.",
    "One day and 12 events: findings describe patterns, not rates. Re-run the script on a larger log before trusting thresholds.",
    "Users are pseudonymous IDs and all IPs are documentation addresses; no secrets or personal data appear in this report.",
    "Analysis was done offline on the supplied file. No external system was scanned, probed or contacted.",
])
S.append(P("Reproduce: <font name='DV-B'>python src/investigation.py</font> (prints rules and writes out/normalized_log.csv, out/findings.json), "
           "then <font name='DV-B'>python src/make_workbook.py</font> and <font name='DV-B'>python src/make_report.py</font>.", "note"))

doc = SimpleDocTemplate(str(ROOT / "incident-report.pdf"), pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm,
                        topMargin=16 * mm, bottomMargin=18 * mm, title="Incident Report - Suspicious Authentication Activity",
                        author="Security Log Investigation")
doc.build(S, onFirstPage=footer, onLaterPages=footer)
print("saved incident-report.pdf")
