#!/usr/bin/env python3
"""Security Log Investigation - reproducible analysis of authentication-log-sample.csv.

Pipeline: load -> normalise -> data-quality checks -> baseline -> detection rules -> metrics.
Standard library only.   Usage:  python src/investigation.py [path/to/log.csv]
Everything the workbook and PDF report show is computed here (single source of truth).
"""
import csv
import ipaddress
import json
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

# ------------------------------------------------------------------ settings
THRESH = {
    "bf_window_s": 300, "bf_min_failures": 3,                  # R1 brute force (one account)
    "spray_window_s": 120, "spray_min_accounts": 3,            # R2 password spraying (one IP)
    "spray_max_per_account": 2,
    "unusual_lookback_s": 24 * 3600,                           # R3 unusual access
}
DOC_RANGES = {"192.0.2.0/24": "TEST-NET-1", "198.51.100.0/24": "TEST-NET-2",
              "203.0.113.0/24": "TEST-NET-3"}                  # RFC 5737 documentation ranges
USER_RE = re.compile(r"^stu-\d{3}$")
EVENT_CLASS = {"password_login": "authentication", "refresh_token": "session",
               "account_lock": "control", "rate_limit": "control"}
OUTCOME = {("password_login", "success"): "login_success",
           ("password_login", "failure"): "login_failure",
           ("refresh_token", "success"): "token_refreshed",
           ("account_lock", "success"): "account_locked",      # 'success' = lock applied, NOT a login
           ("rate_limit", "blocked"): "request_blocked"}
EXPECTED = ["timestamp", "user_id", "source_ip", "event", "result", "device"]


def fmt_td(seconds):
    seconds = int(round(seconds))
    h, r = divmod(seconds, 3600)
    m, s = divmod(r, 60)
    parts = ([f"{h} h"] if h else []) + ([f"{m} min"] if m else []) + ([f"{s} s"] if s or not (h or m) else [])
    return " ".join(parts)


# ------------------------------------------------------------- normalisation
def parse_ts(raw):
    raw = raw.strip()
    dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def load_and_normalise(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        header = [h.strip().lower() for h in (reader.fieldnames or [])]
        rows = [{k.strip().lower(): (v or "").strip() for k, v in r.items()} for r in reader]
    raw_rows = [dict(r) for r in rows]
    issues, events = [], []
    for i, r in enumerate(rows, start=2):  # file line numbers
        try:
            ts = parse_ts(r["timestamp"])
        except (ValueError, KeyError):
            issues.append((i, "invalid timestamp")); continue
        try:
            ip = ipaddress.ip_address(r["source_ip"])
        except ValueError:
            issues.append((i, "invalid IP")); continue
        user = r["user_id"].lower()
        if not USER_RE.match(user):
            issues.append((i, "user_id outside expected pattern"))
        event, result = r["event"].lower(), r["result"].lower()
        cls = EVENT_CLASS.get(event, "other")
        net = ipaddress.ip_network(f"{ip}/24", strict=False)
        rng = next((n for c, n in DOC_RANGES.items() if ip in ipaddress.ip_network(c)), "other")
        device = r["device"].lower()
        events.append({
            "ts": ts, "ts_utc": ts.strftime("%Y-%m-%dT%H:%M:%SZ"), "user_id": user,
            "source_ip": str(ip), "ip_range": rng, "subnet24": str(net),
            "event": event, "event_class": cls, "result_raw": result,
            "outcome": OUTCOME.get((event, result), f"{event}:{result}"),
            "device": device, "device_known": device != "unknown",
            "auth_failure": int(cls == "authentication" and result == "failure"),
            "auth_success": int(cls == "authentication" and result == "success"),
            "control_event": int(cls == "control"),
        })
    events.sort(key=lambda e: e["ts"])  # stable: ties keep file order
    for n, e in enumerate(events, start=1):
        e["event_id"] = f"E{n:02d}"
    return {"header": header, "raw_rows": raw_rows, "events": events, "issues": issues}


def data_quality(data):
    ev, raw = data["events"], data["raw_rows"]
    out = []
    out.append(("Header matches expected schema", data["header"] == EXPECTED, f"columns: {', '.join(data['header'])}"))
    out.append(("Rows parsed / rows in file", len(ev) == len(raw), f"{len(ev)} of {len(raw)}"))
    missing = sum(1 for r in raw for v in r.values() if v == "")
    out.append(("Missing values", missing == 0, f"{missing} empty cells"))
    dup = len(raw) - len({tuple(r.values()) for r in raw})
    out.append(("Exact duplicate rows", dup == 0, f"{dup} duplicates"))
    out.append(("Timestamps valid ISO-8601 UTC ('Z')", all(r["timestamp"].endswith("Z") for r in raw), "all converted to UTC"))
    in_order = [parse_ts(r["timestamp"]) for r in raw] == sorted(parse_ts(r["timestamp"]) for r in raw)
    out.append(("File already in chronological order", in_order, "sorted anyway for analysis"))
    out.append(("IPs valid and inside documentation ranges", all(e["ip_range"] != "other" for e in ev),
                f"{Counter(e['ip_range'] for e in ev)['TEST-NET-1'] + Counter(e['ip_range'] for e in ev)['TEST-NET-2'] + Counter(e['ip_range'] for e in ev)['TEST-NET-3']} of {len(ev)}"))
    out.append(("user_id matches stu-NNN", not any('pattern' in m for _, m in data['issues']), "all 6 accounts"))
    unk = [e["event_id"] for e in ev if e["event_class"] == "other"]
    out.append(("Every event name recognised", not unk, "4 event types"))
    n_unknown = sum(1 for e in ev if not e["device_known"])
    out.append(("Device field populated with a real value", n_unknown == 0,
                f"{n_unknown} rows have device='unknown' (all from one IP) - treated as a signal, not as missing"))
    out.append(("Result semantics differ by event", False,
                "'success' on account_lock means the lock was applied, not that a user logged in; "
                "normalised into 'outcome' + auth_success flag so it is never counted as a login"))
    return out


# ------------------------------------------------------------------ baseline
def baseline(data):
    ev = data["events"]
    auth = [e for e in ev if e["event_class"] == "authentication"]
    fails = [e for e in auth if e["auth_failure"]]
    span = (ev[-1]["ts"] - ev[0]["ts"]).total_seconds()
    per_ip = {}
    for ip in sorted({e["source_ip"] for e in ev}):
        rows = [e for e in ev if e["source_ip"] == ip]
        f = [e for e in rows if e["auth_failure"]]
        per_ip[ip] = {"events": len(rows), "failures": len(f), "successes": sum(e["auth_success"] for e in rows),
                      "distinct_accounts_failed": len({e["user_id"] for e in f}),
                      "devices": sorted({e["device"] for e in rows})}
    per_user = {}
    for u in sorted({e["user_id"] for e in ev}):
        rows = [e for e in ev if e["user_id"] == u]
        per_user[u] = {"events": len(rows), "failures": sum(e["auth_failure"] for e in rows),
                       "successes": sum(e["auth_success"] for e in rows),
                       "ips": sorted({e["source_ip"] for e in rows})}
    return {"total_events": len(ev), "first": ev[0]["ts_utc"], "last": ev[-1]["ts_utc"], "span_s": span,
            "password_logins": len(auth), "failures": len(fails), "successes": len(auth) - len(fails),
            "failure_rate": len(fails) / len(auth), "distinct_users": len(per_user), "distinct_ips": len(per_ip),
            "events_by_hour": dict(Counter(e["ts"].strftime("%H:00") for e in ev)),
            "per_ip": per_ip, "per_user": per_user,
            "reference_pattern": "stu-104: password login 09:00:12 then token refresh 10:15:32, same IP 192.0.2.18 and device android"}


# ------------------------------------------------------------ detection rules
def _clusters(events, window, accept):
    """Greedy sliding window over time-sorted events; accept(window_events)->bool."""
    out, i = [], 0
    while i < len(events):
        j = i
        while j + 1 < len(events) and (events[j + 1]["ts"] - events[i]["ts"]).total_seconds() <= window:
            j += 1
        win = events[i:j + 1]
        if accept(win):
            out.append(win); i = j + 1
        else:
            i += 1
    return out


def rule_bruteforce(ev):
    res = []
    by_user = defaultdict(list)
    for e in ev:
        if e["auth_failure"]:
            by_user[e["user_id"]].append(e)
    for u, fl in by_user.items():
        for win in _clusters(fl, THRESH["bf_window_s"], lambda w: len(w) >= THRESH["bf_min_failures"]):
            res.append({"rule": "R1", "user_id": u, "ips": sorted({e["source_ip"] for e in win}),
                        "devices": sorted({e["device"] for e in win}), "count": len(win),
                        "events": [e["event_id"] for e in win],
                        "start": win[0]["ts_utc"], "end": win[-1]["ts_utc"],
                        "duration_s": (win[-1]["ts"] - win[0]["ts"]).total_seconds(),
                        "gaps_s": [(b["ts"] - a["ts"]).total_seconds() for a, b in zip(win, win[1:])]})
    return res


def rule_spray(ev):
    res = []
    by_ip = defaultdict(list)
    for e in ev:
        if e["auth_failure"]:
            by_ip[e["source_ip"]].append(e)

    def ok(w):
        c = Counter(e["user_id"] for e in w)
        return len(c) >= THRESH["spray_min_accounts"] and max(c.values()) <= THRESH["spray_max_per_account"]
    for ip, fl in by_ip.items():
        for win in _clusters(fl, THRESH["spray_window_s"], ok):
            res.append({"rule": "R2", "source_ip": ip, "accounts": [e["user_id"] for e in win],
                        "devices": sorted({e["device"] for e in win}), "count": len(win),
                        "events": [e["event_id"] for e in win], "start": win[0]["ts_utc"], "end": win[-1]["ts_utc"],
                        "duration_s": (win[-1]["ts"] - win[0]["ts"]).total_seconds(),
                        "gaps_s": [(b["ts"] - a["ts"]).total_seconds() for a, b in zip(win, win[1:])]})
    return res


def rule_unusual_access(ev):
    res = []
    for e in ev:
        if not e["auth_success"]:
            continue
        prior = [p for p in ev if p["user_id"] == e["user_id"] and p["ts"] < e["ts"]]
        known = {(p["source_ip"], p["device"]) for p in prior if p["auth_success"] or p["event_class"] == "session"}
        new_pair = (e["source_ip"], e["device"]) not in known
        recent = [p for p in prior if p["auth_failure"] and
                  (e["ts"] - p["ts"]).total_seconds() <= THRESH["unusual_lookback_s"]]
        r = {"rule": "R3", "event": e["event_id"], "user_id": e["user_id"], "source_ip": e["source_ip"],
             "device": e["device"], "baseline_history_events": len(prior), "new_ip_device_pair": new_pair,
             "prior_failures_24h": len(recent), "fired": bool(new_pair and recent)}
        if recent:
            last = recent[-1]
            r.update({"exposure_events": [p["event_id"] for p in recent],
                      "exposure_ips": sorted({p["source_ip"] for p in recent}),
                      "since_last_failure_s": (e["ts"] - last["ts"]).total_seconds(),
                      "same_24_as_known_good_ip": any(
                          x["subnet24"] == e["subnet24"] and x["source_ip"] != e["source_ip"] and x["auth_success"]
                          for x in ev if x["ts"] < e["ts"])})
        res.append(r)
    return res


def control_latency(ev, bf, spray):
    out = []
    for c in bf:
        locks = [e for e in ev if e["event"] == "account_lock" and e["user_id"] == c["user_id"]
                 and e["ts_utc"] >= c["end"]]
        if locks:
            lk = locks[0]
            out.append({"control": "account_lock", "event": lk["event_id"], "user_id": c["user_id"],
                        "after_threshold_s": (lk["ts"] - parse_ts(c["end"])).total_seconds(),
                        "after_first_failure_s": (lk["ts"] - parse_ts(c["start"])).total_seconds()})
    for c in spray:
        rl = [e for e in ev if e["event"] == "rate_limit" and e["source_ip"] == c["source_ip"]
              and e["ts_utc"] >= c["end"]]
        if rl:
            r = rl[0]
            out.append({"control": "rate_limit", "event": r["event_id"], "user_id": r["user_id"],
                        "after_threshold_s": (r["ts"] - parse_ts(c["end"])).total_seconds(),
                        "after_first_failure_s": (r["ts"] - parse_ts(c["start"])).total_seconds(),
                        "accounts_probed_before_block": len(set(c["accounts"]))})
    return out


def analyse(path):
    data = load_and_normalise(path)
    ev = data["events"]
    bf, sp, ua = rule_bruteforce(ev), rule_spray(ev), rule_unusual_access(ev)
    return {"data": data, "dq": data_quality(data), "baseline": baseline(data),
            "r1": bf, "r2": sp, "r3": ua, "latency": control_latency(ev, bf, sp)}


if __name__ == "__main__":
    here = Path(__file__).resolve().parent.parent
    src = Path(sys.argv[1]) if len(sys.argv) > 1 else here / "authentication-log-sample.csv"
    R = analyse(src)
    out = here / "out"; out.mkdir(exist_ok=True)
    cols = ["event_id", "ts_utc", "user_id", "source_ip", "ip_range", "subnet24", "event", "event_class",
            "result_raw", "outcome", "device", "device_known", "auth_failure", "auth_success", "control_event"]
    with open(out / "normalized_log.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore"); w.writeheader(); w.writerows(R["data"]["events"])
    summary = {k: R[k] for k in ("dq", "baseline", "r1", "r2", "r3", "latency")}
    (out / "findings.json").write_text(json.dumps(summary, indent=2, default=str))
    print(f"Events: {R['baseline']['total_events']}   span: {fmt_td(R['baseline']['span_s'])}")
    print("Data quality:"); [print(f"  [{'ok' if ok else '!!'}] {n}: {d}") for n, ok, d in R["dq"]]
    print("R1 brute force :", [(c['user_id'], c['events'], f"{c['duration_s']:.0f}s") for c in R["r1"]])
    print("R2 spraying    :", [(c['source_ip'], c['accounts'], f"{c['duration_s']:.0f}s") for c in R["r2"]])
    print("R3 unusual     :", [(r['event'], r['user_id'], 'FIRED' if r['fired'] else 'no') for r in R["r3"]])
    print("Control latency:", [(l['control'], f"{l['after_threshold_s']:.0f}s after threshold") for l in R["latency"]])
