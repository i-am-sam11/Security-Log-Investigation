# Security Log Investigation

Defensive analysis of a synthetic student-portal authentication log (12 events, RFC 5737 documentation IPs).
No external systems were scanned or contacted.

## Deliverables

| File | What it is |
|---|---|
| `incident-report.pdf` | 6-page incident report: findings, timeline, evidence vs assumptions, recommendations |
| `security-log-investigation.xlsx` | Investigation workbook: raw and normalized log, data quality, baseline, detection rules with live formula tests, findings, timeline, threat model, recommendations |
| `timeline.png` | Event timeline chart used in the report |
| `authentication-log-sample.csv` | The supplied synthetic log (unmodified) |
| `src/` | Reproducible analysis: `investigation.py` (engine), `narrative.py`, `make_workbook.py`, `make_report.py`, `make_chart.py` |
| `out/` | `normalized_log.csv`, `findings.json` produced by the engine |

## Findings in brief

- **F1 (Low):** stu-117, 3 failed logins in 34 s then lockout. Likely a user mistake.
- **F2 (High):** 203.0.113.42 tried 4 different accounts in 12 s, device unknown. Password-spraying pattern, rate-limited.
- **F3 (High, provisional):** stu-311, a spray target, logged in 2 h 25 min later from a new IP and device. Unconfirmed; verify with the owner.

## Checklist mapping

1. **Normalize timestamps, IPs, accounts, actions, results:** `Normalized_Log` and `Data_Quality` sheets; report section 2.
2. **Detection rules for spraying, brute force, unusual access:** rules R1-R3 (plus R4 control health) in `Detection_Rules` with live tests; report section 4.
3. **Timeline, evidence separated from assumptions:** `Timeline` and `Evidence_vs_Assumptions` sheets; report sections 6-7.

## Reproduce

```bash
python src/investigation.py   # prints rule results, writes out/
python src/make_chart.py && python src/make_workbook.py && python src/make_report.py
```
Needs Python 3.8+, `openpyxl`, `reportlab`, `matplotlib` for the workbook/report builders (the analysis engine itself uses only the standard library).
